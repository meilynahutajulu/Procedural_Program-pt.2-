// NIM - Name
// NIM - Name

#include <stdio.h>

int main(int _argc, char **_argv) {
  // codes

  return 0;
}
